import React, { useState, useEffect } from 'react';
import { 
  motion, 
  AnimatePresence 
} from 'framer-motion';
import { 
  MessageCircle, 
  Factory, 
  Building2, 
  Warehouse, 
  BarChart3, 
  Store,
  ArrowDownCircle,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  Quote
} from 'lucide-react';

// --- Constants ---
const WHATSAPP_NUMBER = "966596901871";
const WHATSAPP_MESSAGE = "السلام عليكم، أرغب في طلب خدمة حلول منصة مدد ورفع نسبة الالتزام في حماية الإجور.";
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`;

// --- Components ---

const WhatsAppLink = ({ className, children }: { className?: string, children: React.ReactNode }) => (
  <a 
    href={WHATSAPP_URL} 
    target="_blank" 
    rel="noopener noreferrer" 
    className={className}
  >
    {children}
  </a>
);

const TopBar = () => (
  <div className="bg-[#1E3A8A] text-white py-3 px-4 sticky top-0 z-50 shadow-lg">
    <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
      <div className="flex items-center gap-2 font-bold">
        <ShieldCheck className="w-5 h-5 text-[#10B981]" />
        <span>حلول منصة مُدد وحماية الإجور</span>
      </div>
      <WhatsAppLink className="flex items-center gap-2 hover:text-[#10B981] transition-colors font-bold text-sm md:text-base">
        <MessageCircle className="w-5 h-5 fill-current text-[#10B981]" />
        <span dir="ltr">+{WHATSAPP_NUMBER}</span>
        <span className="hidden sm:inline">تواصل معنا عبر واتساب</span>
      </WhatsAppLink>
    </div>
  </div>
);

const HeroSection = () => (
  <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden bg-slate-50 py-20 px-6">
    {/* Floating 3D-like background shapes */}
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          animate={{
            y: [0, -30, 0],
            rotate: [0, 45, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 8 + i,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute bg-[#1E3A8A]/5 blur-3xl rounded-full"
          style={{
            width: `${100 + i * 50}px`,
            height: `${100 + i * 50}px`,
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
        />
      ))}
    </div>

    <div className="container mx-auto text-center relative z-10">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="inline-block bg-blue-100 text-[#1E3A8A] px-6 py-2 rounded-full font-black text-sm mb-8 border border-blue-200 shadow-sm"
      >
        رفع الالتزام إلى 100% مضمون بإذن الله
      </motion.div>
      
      <motion.h1 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-4xl md:text-7xl font-black text-slate-900 leading-tight mb-8"
      >
        ارفع التزامك في حماية <span className="text-[#1E3A8A]">الإجور</span> إلى 100% في منصة مُدد
      </motion.h1>
      
      <motion.h2 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="text-2xl md:text-3xl font-bold text-slate-600 mb-6"
      >
        وحل مشاكل الغرامات والملاحظات بدون تحويل رواتب!
      </motion.h2>

      <motion.p 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="text-lg md:text-xl text-slate-500 max-w-3xl mx-auto mb-12 leading-relaxed"
      >
        حلول للمنشآت الكبيرة (من موظف واحد إلى آلاف الموظفين) - نتعامل بسرعة واحترافية وبدون أي تعقيدات تقنية.
      </motion.p>
      
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="flex flex-col sm:flex-row items-center justify-center gap-4"
      >
        <WhatsAppLink className="bg-[#10B981] hover:bg-emerald-600 text-white px-10 py-5 rounded-2xl text-xl font-black shadow-[0_10px_30px_rgba(16,185,129,0.3)] transition-all hover:-translate-y-1 flex items-center gap-3">
          <MessageCircle className="w-7 h-7" />
          تواصل الآن عبر واتساب
        </WhatsAppLink>
        <button 
          onClick={() => document.getElementById('steps')?.scrollIntoView({ behavior: 'smooth' })}
          className="bg-white hover:bg-slate-100 text-slate-800 px-10 py-5 rounded-2xl text-xl font-bold border border-slate-200 shadow-sm transition-all hover:-translate-y-1 flex items-center gap-3"
        >
          تعرف على الخدمة
          <ArrowDownCircle className="w-6 h-6 animate-bounce" />
        </button>
      </motion.div>
    </div>
  </section>
);

const StepsSection = () => {
  const steps = [
    {
      title: "تتواصل معنا على واتساب",
      desc: "لإرسال بيانات المنشأة المطلوبة لبدء العمل فوراً.",
      icon: <MessageCircle className="w-10 h-10 text-white" />
    },
    {
      title: "يتم الرد عليك",
      desc: "ليتم طلب ملفات ورفعها من عندنا بطريقة احترافية ومضمونة.",
      icon: <Warehouse className="w-10 h-10 text-white" />
    },
    {
      title: "نؤكد إزالة الملاحظة",
      desc: "نؤكد إزالة ملاحظة حماية الإجور ورفع الالتزام إلى 100% في مُدد.",
      icon: <ShieldCheck className="w-10 h-10 text-white" />
    }
  ];

  return (
    <section id="steps" className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-6">الخدمة في 3 خطوات</h2>
          <p className="text-xl text-slate-500">طريقة عملنا سهلة، سريعة، وموثوقة</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {steps.map((step, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -10, rotateX: 5, rotateY: 5 }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="bg-white p-10 rounded-[2.5rem] shadow-2xl border border-slate-50 text-center relative group"
              style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
            >
              <div className="w-20 h-20 bg-[#1E3A8A] rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-lg transform rotate-6 transition-transform group-hover:rotate-0">
                {step.icon}
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-6">{step.title}</h3>
              <p className="text-lg text-slate-600 leading-relaxed">{step.desc}</p>
              <div className="absolute top-6 right-8 text-6xl font-black text-slate-100 -z-10 group-hover:text-blue-50 transition-colors">
                0{idx + 1}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const AchievementsSection = () => {
  return (
    <section className="py-24 bg-slate-50 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-6">نماذج من إنجازاتنا</h2>
          <p className="text-xl text-slate-500">نحول منشأتك من الملاحظات إلى الالتزام التام</p>
        </div>

        <div className="flex flex-col lg:flex-row items-center justify-center gap-12 max-w-6xl mx-auto">
          {/* Before */}
          <motion.div 
            whileHover={{ rotateY: -10, translateZ: 20 }}
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-white p-8 rounded-[3rem] shadow-2xl border-4 border-slate-100 flex-1 w-full text-center"
            style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
          >
            <div className="mb-8">
              <div className="w-32 h-32 rounded-full border-[10px] border-slate-100 mx-auto flex items-center justify-center mb-4">
                <span className="text-4xl font-black text-slate-300">0%</span>
              </div>
              <h4 className="text-2xl font-black text-[#1E3A8A]">مؤسسة الراقية</h4>
              <p className="text-slate-400 font-bold mt-2">فبراير (NaN)</p>
            </div>
            <div className="bg-red-50 text-red-600 py-3 rounded-2xl font-black text-xl">
              قبل المعالجة
            </div>
          </motion.div>

          <div className="hidden lg:flex items-center justify-center">
            <motion.div 
              animate={{ x: [0, 10, 0] }} 
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-16 h-16 bg-[#10B981] rounded-full flex items-center justify-center text-white shadow-lg"
            >
              <ChevronLeft className="w-10 h-10" />
            </motion.div>
          </div>

          {/* After */}
          <motion.div 
            whileHover={{ rotateY: 10, translateZ: 20 }}
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-white p-8 rounded-[3rem] shadow-2xl border-4 border-[#10B981]/20 flex-1 w-full text-center"
            style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
          >
            <div className="mb-8">
              <div className="w-32 h-32 rounded-full border-[10px] border-[#10B981] mx-auto flex items-center justify-center mb-4 relative overflow-hidden">
                <motion.div 
                  initial={{ height: 0 }} 
                  whileInView={{ height: '100%' }} 
                  transition={{ duration: 1.5 }}
                  className="absolute bottom-0 left-0 w-full bg-[#10B981]/10"
                />
                <span className="text-4xl font-black text-[#10B981] relative z-10">100%</span>
              </div>
              <h4 className="text-2xl font-black text-[#1E3A8A]">مؤسسة الراقية</h4>
              <p className="text-[#10B981] font-bold mt-2">فبراير (NaN)</p>
            </div>
            <div className="bg-[#10B981] text-white py-3 rounded-2xl font-black text-xl shadow-lg">
              بعد المعالجة
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const TestimonialsSection = () => {
  const [index, setIndex] = useState(0);
  const testimonials = [
    {
      text: "كان عندي ملاحظة في منصة مُدد بسبب عمال في إجازة، تواصلت معهم وتم الحل في نفس اليوم! الخدمة سريعة وموثوقة جداً، أنصح بهم بشدة.",
      name: "أحمد محمد",
      role: "مدير مصنع"
    },
    {
      text: "نسبتنا كانت متدنية بسبب موظفين هاربين، الفريق رفع الالتزام ليوم 100% خلال ساعات قليلة بدون تعقيدات، وفرت غرامات كبيرة جداً.",
      name: "سارة العلي",
      role: "صاحبة مؤسسة تجارية"
    },
    {
      text: "أنصح بهم بشدة! خدمتهم خلصت مشكلة الملاحظات في مُدد بسرعة فائقة وتوفير كبير في الغرامات، خدمة احترافية جداً!",
      name: "خالد السالم",
      role: "مدير مؤسسة"
    }
  ];

  const next = () => setIndex((prev) => (prev + 1) % testimonials.length);
  const prev = () => setIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-24 bg-slate-900 text-white overflow-hidden relative">
      <div className="container mx-auto px-6 relative z-10">
        <h2 className="text-3xl md:text-5xl font-black text-center mb-16">ماذا يقول عملاؤنا؟</h2>
        
        <div className="relative max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -50, scale: 0.9 }}
              transition={{ duration: 0.5 }}
              className="bg-white/5 backdrop-blur-xl p-12 md:p-20 rounded-[3rem] border border-white/10 text-center"
            >
              <Quote className="w-16 h-16 text-[#10B981] mx-auto mb-10 opacity-50" />
              <p className="text-2xl md:text-3xl leading-relaxed italic mb-10">"{testimonials[index].text}"</p>
              <div>
                <h4 className="text-2xl font-black text-[#10B981]">{testimonials[index].name}</h4>
                <p className="text-lg text-slate-400 font-bold">{testimonials[index].role}</p>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-center gap-6 mt-12">
            <button onClick={prev} className="p-4 rounded-full bg-white/10 hover:bg-white/20 transition-all border border-white/10">
              <ChevronRight className="w-6 h-6" />
            </button>
            <button onClick={next} className="p-4 rounded-full bg-white/10 hover:bg-white/20 transition-all border border-white/10">
              <ChevronLeft className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const WarningCTASection = () => (
  <section className="py-24 px-6 bg-white overflow-hidden">
    <div className="container mx-auto">
      <motion.div 
        whileHover={{ scale: 1.02, rotateX: 2 }}
        initial={{ opacity: 0, y: 100 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-gradient-to-br from-red-600 via-red-700 to-red-900 rounded-[4rem] p-12 md:p-24 text-center text-white shadow-[0_40px_100px_rgba(220,38,38,0.4)] relative border-4 border-red-500/30"
        style={{ perspective: '2000px', transformStyle: 'preserve-3d' }}
      >
        {/* Particle-like elements in CTA */}
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_white_1px,_transparent_1px)] bg-[length:40px_40px]" />
        </div>

        <div className="relative z-10 flex flex-col items-center">
          <motion.div 
            animate={{ scale: [1, 1.2, 1], rotate: [0, 5, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="mb-10 bg-white/20 p-6 rounded-full shadow-2xl"
          >
            <AlertTriangle className="w-20 h-20 text-yellow-300" />
          </motion.div>

          <h2 className="text-4xl md:text-7xl font-black mb-8 leading-tight drop-shadow-2xl">
            تحذير: بادر بالحل قبل صدور الغرامات...
          </h2>
          <p className="text-xl md:text-3xl text-red-50 mb-12 max-w-4xl mx-auto font-bold leading-relaxed">
            لا تنتظر حتى تصل المخالفة المالية الضخمة، فريقنا المختص جاهز لمعالجة كافة ملاحظات مُدد ورفع التزام حماية الإجور فوراً وبطريقة نظامية 100%.
          </p>

          <WhatsAppLink className="bg-[#10B981] hover:bg-emerald-600 text-white px-16 py-8 rounded-[2rem] text-3xl font-black shadow-[0_20px_50px_rgba(16,185,129,0.5)] transition-all hover:scale-110 active:scale-95 border-b-[10px] border-emerald-800 flex items-center gap-4">
            <MessageCircle className="w-10 h-10 fill-current" />
            <span>تواصل معنا عبر واتساب الآن</span>
          </WhatsAppLink>
        </div>
      </motion.div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="bg-slate-900 text-slate-500 py-16 px-6">
    <div className="container mx-auto text-center">
      <div className="flex items-center justify-center gap-3 mb-8">
        <ShieldCheck className="w-8 h-8 text-[#10B981]" />
        <span className="text-3xl font-black text-white">حلول منصة مُدد وحماية الإجور</span>
      </div>
      <p className="text-xl font-bold mb-8">جميع الحقوق محفوظة © 2024</p>
      <div className="flex justify-center gap-8 text-lg font-bold">
        <WhatsAppLink className="hover:text-white transition-colors">واتساب</WhatsAppLink>
        <span className="text-slate-800">|</span>
        <a href="#steps" className="hover:text-white transition-colors">الخدمات</a>
      </div>
    </div>
  </footer>
);

export function App() {
  return (
    <div className="min-h-screen bg-white font-cairo" dir="rtl">
      <TopBar />
      <HeroSection />
      <StepsSection />
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-black text-center mb-16 text-slate-800">نخدم جميع أنواع المنشآت في المملكة</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            {[
              { name: "مصانع", icon: <Factory className="w-12 h-12" /> },
              { name: "شركات", icon: <Building2 className="w-12 h-12" /> },
              { name: "مؤسسات", icon: <Warehouse className="w-12 h-12" /> },
              { name: "مكاتب استشارية", icon: <BarChart3 className="w-12 h-12" /> },
              { name: "منشآت كبيرة", icon: <Store className="w-12 h-12" /> }
            ].map((item, i) => (
              <motion.div key={i} whileHover={{ scale: 1.1 }} className="flex flex-col items-center gap-4 p-6 bg-white rounded-3xl shadow-lg border border-slate-100">
                <div className="text-[#1E3A8A]">{item.icon}</div>
                <span className="font-black text-slate-700">{item.name}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      <AchievementsSection />
      <TestimonialsSection />
      <WarningCTASection />
      <Footer />
    </div>
  );
}
